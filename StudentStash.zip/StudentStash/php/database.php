<?php
// Database connection
$servername = "localhost";
$username = "root"; // Your MySQL username
$password = ""; // Your MySQL password
$dbname = "StudentStash"; // Your database name

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Form submission handling
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $email = $_POST['email'];
    $password = $_POST['password'];

    // SQL query to check if email and password match
    $sql = "SELECT * FROM loginform WHERE email='$email' AND password='$password'";
    $result = $conn->query($sql);

    if ($result->num_rows > 0) {
        // Login successful
        // Redirect to a success page or perform other actions
        header("Location: index.html");
        exit();
    } else {
        // Login failed
        // Redirect back to the login page with an error message
        header("Location: login.html?error=1");
        exit();
    }
}

$conn->close();
?>
