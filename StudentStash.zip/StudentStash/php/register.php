<?php
// Database connection
$servername = "localhost";
$username = "root"; // Your MySQL username
$password = ""; // Your MySQL password
$dbname = "StudentStash"; // Your database name

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Form submission handling
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $name = $_POST['name'];
    $email = $_POST['email'];
    $password = $_POST['password'];

    // SQL query to insert user data into the database
    $sql = "INSERT INTO registration (name, email, password) VALUES ('$name', '$email', '$password')";

    if ($conn->query($sql) === TRUE) {
        // Registration successful
        // Redirect to a success page or perform other actions
        header("Location: login.html");
        exit();
    } else {
        // Registration failed
        // Redirect back to the registration page with an error message
        header("Location: registration.html?error=1");
        exit();
    }
}

$conn->close();
?>
